# -*- coding: utf-8 -*-

__author__ = 'Awais khan'
__all__ = ()

import logging
logger = logging.getLogger('senlib')
